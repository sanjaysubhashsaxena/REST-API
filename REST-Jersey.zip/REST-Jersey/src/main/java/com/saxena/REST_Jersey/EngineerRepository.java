package com.saxena.REST_Jersey;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class EngineerRepository {
	static Configuration configuration = new Configuration().configure().addAnnotatedClass(Engineer.class);
	static SessionFactory factory = configuration.buildSessionFactory();
	static Session session = factory.openSession();
	
	static void addEngineer(int id,String name) {
		session.beginTransaction();
		Engineer engineer = new Engineer();
		engineer.setId(id);
		engineer.setName(name);
		session.save(engineer);
		session.getTransaction().commit();
	}

	public Engineer getEngineer(int id) {
		session.beginTransaction();
		Query query = session.createQuery("from Engineer where id="+id);
		Engineer engineer = (Engineer) query.uniqueResult();
		session.getTransaction().commit();
		return engineer;	
	}

	public void updateEngineer(int id, String name) {
		session.beginTransaction();
		String query2 ="update Engineer set name= :eng_name " + "where id=:eng_id";
		Query query = session.createQuery(query2);
		query.setParameter("eng_name",name);
		query.setParameter("eng_id",id);
		int result=query.executeUpdate();
		System.out.println("Row affected: "+result);
		session.getTransaction().commit();
		session.close();
	}
	
	public void deleteEngineer(int id) {
		session.beginTransaction();
		Query query3 = session.createQuery("from Engineer where id="+id);
		Engineer eng = (Engineer) query3.uniqueResult();
		session.delete(eng);
		session.getTransaction().commit();
		session.close();
		
	}
}
