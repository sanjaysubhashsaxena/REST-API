package com.saxena.REST_Jersey;

import java.util.ArrayList;
import java.util.List;

public class EmployeeRepository {
	List<Employee> list = new ArrayList<Employee>();

	/*
	 * WHEN THE CLASS LOAD DEFAULT CONSTRUCTOR,
	 * INITIALIZED THE VALUE
	 */
	public EmployeeRepository() {
		Employee emp = new Employee();
		emp.setName("Sanjay");
		emp.setPoints(60);
		Employee emp2 = new Employee();
		emp2.setName("Sam");
		emp2.setPoints(100);
		list.add(emp);
		list.add(emp2);
	}
	
	/*
	 * THIS FUNCTION RETURN LIST OF EMPLOYEE], 
	 * WHICH WE HAVE INITIALIZED USING DEFAULT
	 * CONSTRUCTOR
	 */
	public List<Employee> getEmployee() {
		return list;
	}

	/*
	 * THIS METHOD CHECK AND ACT LIKE PRIMARY KEY
	 */
	public Employee getEmployee(String name) {
		System.out.println("Name inside the repo "+name);
		for (Employee e : list) {
			System.out.println("Name inside the repo list "+e.getName());
			if (e.getName().equals(name)) {
				return e;
			}
		}
		return null;
	}

	/*
	 * THIS METHOD CREATE NEW EMPLOYEE
	 */
	public void create(Employee emp) {
		// TODO Auto-generated method stub
		list.add(emp);

	}
}
