package com.saxena.REST_Jersey;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;
/*
 * @XmlRootElement ANNOTATION PREPARE 
 * POJO CLASS IN THE XML STRUTURE
 */
@XmlRootElement
@Entity
public class Engineer {
	@Id
	private int id;
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Engineer [name=" + name + ", id=" + id + "]";
	}

}
