package com.saxena.REST_Jersey;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sun.org.glassfish.gmbal.ParameterNames;

@Path("employees")
public class EmployeeResource {
	EmployeeRepository repo=new EmployeeRepository();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Employee> getEmployee() {
		System.out.println("getEmployee Resource called!");
		return repo.getEmployee();
	}
	/*
	 * CRULY BRACKET IS CALLED PLACEHOLDER,
	 * WHICH HOLDS THE VALUE, AND THEN WITH
	 * THE HELP OF PATHPARAM WE ARE CONVERTING
	 * THIS VALUE
	 */
	@GET
	@Path("getemp/{name}")
	@Produces(MediaType.APPLICATION_XML)
	public Employee getEmployee(@PathParam("name") String name) {
		System.out.println("Name--------->"+name);
		return repo.getEmployee(name);
	}
	
	@POST
	@Path("create")
	public Employee createEmployee(Employee emp) {
		System.out.println(emp);
		repo.create(emp);
		return emp;
	}

}
