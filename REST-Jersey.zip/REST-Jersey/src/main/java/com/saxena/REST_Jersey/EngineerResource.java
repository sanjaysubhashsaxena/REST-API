package com.saxena.REST_Jersey;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sun.org.glassfish.gmbal.ParameterNames;

/*
 * Root resource for Engineer (exposed at "engineers" path)
 */
@Path("engineers")
public class EngineerResource {
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public void EngineerResource() {
		System.out.println("Resource called!");

	}

	EngineerRepository repo = new EngineerRepository();

	@GET
	@Path("getdetail/{id}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Engineer getEngineer(@PathParam("id") int id) {
		System.out.println("Id--------->" + id);
		System.out.println(repo.getEngineer(id));
		return repo.getEngineer(id);
	}

	@POST
	@Path("add")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Engineer createEngineer(Engineer emp) {
		int id = emp.getId();
		String name = emp.getName();
		repo.addEngineer(id, name);
		return emp;
	}

	@PUT
	@Path("update")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public void update(Engineer emp) {
		int id = emp.getId();
		String name = emp.getName();
		repo.updateEngineer(id, name);
		System.out.println("Updated Successfully!");
	}
	
	@DELETE
	@Path("delete")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public void delete(Engineer emp) {
		int id = emp.getId();
		repo.deleteEngineer(id);
		System.out.println("Delete Successfully!");
	}

}
